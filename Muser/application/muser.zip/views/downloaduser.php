<?php 

$date=$_REQUEST['date'];
$date=strip_tags($date);

function validateDate($date, $format = 'Y-m-d')
{
	$d = DateTime::createFromFormat($format, $date);
	// The Y ( 4 digits year ) returns TRUE for any integer with any number of digits so changing the comparison from == to === fixes the issue.
	return $d && $d->format($format) === $date;
}

if(validateDate($date,'Y-m-d')==false){
	echo "Invalid Date";
}
else{
	
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
	<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0  user-scalable=1">
	<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
 <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>User List</title>

    <!-- Bootstrap -->
    <link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
	<link href="<?php echo base_url();?>css/font-awesome.min.css" rel="stylesheet" type="text/css">
   
   <style>
   th,td
   {
   	padding:3px;
   }
   </style>
  </head>
  <body>
    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 no-padding outer-box">
	<div class="col-xs-12 col-sm-12 main-body">
    	<div class="container">
    	
    	<h2 style="text-align:center;color:red;"><b>Mass Venture India</b></h2>
    	
    	<h3 style="text-align:center;color: #414141;">User List</h3>
    	
    	
    	Joined: <?php 
    	
    	$ndate=trim( implode('-', array_reverse(explode('-', $date))));
    	echo $ndate;
    	?>
    	
    	
			<table border="1" class="table"> 
				<thead> 
					<tr> 
						<th style="width:8%;">No</th> 
						<th style="width:35%;">Name</th> 
						<th style="width:20%;">Username</th> 
						<th style="width:10%;">Position</th> 
						<th style="width:10%;text-align:right;">BV</th>
						<th style="width:15%;">Status</th> 
					</tr> 
				</thead> 
				<tbody> 
				
<?php

$id=$_SESSION['uid1'];
$pin=$_SESSION['pin1'];
$tree=0;
$query = $this->db->query("select tree from user_child where u_id='$id'");
foreach ($query->result() as $row)
{
	$tree=$row->tree;
}
$curdate=$this->db->escape($date);


			$query = $this->db->query("SELECT ue.u_name,ul.username,ul.freeuser,ul.activated,
							(SELECT 
							CASE
							    WHEN uc1.tree like concat('$tree','0','%') THEN 'Left'
							    ELSE 'Right'
							END
							FROM user_child uc1 where uc1.u_id=uc.u_id) as position ,
							(select sum(pd.bv) from user_product_prefer upp,product_details pd where upp.product_id=pd.product_id and upp.u_id=ul.u_id) as tbv
							FROM user_extradetails ue,user_login ul,user_child uc 
							where  uc.tree like concat('$tree','%') and ue.u_joindate=$curdate and uc.u_id=ue.u_id and ul.u_id=ue.u_id and ul.u_id!='$id' order by ul.u_id asc");

			$ix=0;
			foreach ($query->result() as $row1)
			{$ix++;
				$u_name=$row1->u_name;
				$username=$row1->username;
				$freeuser=$row1->freeuser;
				$position=$row1->position;
				$tbv=$row1->tbv;
				$activated=$row1->activated;
				
				if(strtoupper($position)=='RIGHT'){$col="#2977ff";}
				
				if($freeuser==1){$usertype="Free User";$col1="red";}
				else{
					if($activated==0){
						$usertype="Unpaid User";
						$col1="red";
					}
					else{
						$usertype="Paid User";
						$col1="green";
					}
					
				}
				
				
				?>
				<tr>
						<td><?php echo $ix;?></td> 
						<td><?php echo $u_name;?></td> 
						<td><?php echo $username;?></td> 
						<td style="color:<?php echo $col;?>"><?php echo $position;?></td> 
						<td style="text-align:right;"><?php echo $tbv;?></td> 
						<td style="color:<?php echo $col1;?>"><?php echo $usertype;?></td>
				</tr>
				<?php
				
			}
			?>
			
			
				</tbody> 
			</table>
			
			
			
			
			
			
				<p><hr style="color:blue;"></p>
			
			<span style="color:red;">Activated: <?php echo $ndate;?></span>
				<table border="1" class="table" style="margin-top:10px;"> 
				<thead> 
					<tr> 
						<th style="width:8%;">No</th> 
						<th style="width:35%;">Name</th> 
						<th style="width:20%;">Username</th> 
						<th style="width:10%;">Position</th> 
						<th style="width:10%;text-align:right;">BV</th>
						<th style="width:15%;">Status</th> 
					</tr> 
				</thead> 
				<tbody> 
				
<?php

$id=$_SESSION['uid1'];
$pin=$_SESSION['pin1'];
$tree=0;
$query = $this->db->query("select tree from user_child where u_id='$id'");
foreach ($query->result() as $row)
{
	$tree=$row->tree;
}
$curdate=$this->db->escape($date);

mysqli_next_result($this->db->conn_id);
			$query = $this->db->query("SELECT ue.u_name,ul.username,ul.freeuser,ul.activated,
							(SELECT 
							CASE
							    WHEN uc1.tree like concat('$tree','0','%') THEN 'Left'
							    ELSE 'Right'
							END
							FROM user_child uc1 where uc1.u_id=uc.u_id) as position ,
							(select sum(pd.bv) from user_product_prefer upp,product_details pd where upp.product_id=pd.product_id and upp.u_id=ul.u_id) as tbv
							FROM user_extradetails ue,user_login ul,user_child uc 
							where  uc.tree like concat('$tree','%') and uc.u_id=ue.u_id and ul.u_id=ue.u_id and ul.u_id!='$id' and ul.activated='1' and ue.u_activatedate=$curdate order by ul.u_id asc");

			$ix=0;
			foreach ($query->result() as $row1)
			{$ix++;
				$u_name=$row1->u_name;
				$username=$row1->username;
				$freeuser=$row1->freeuser;
				$position=$row1->position;
				$tbv=$row1->tbv;
				$activated=$row1->activated;
				
				if(strtoupper($position)=='RIGHT'){$col="#2977ff";}
				
				if($freeuser==1){$usertype="Free User";$col1="red";}
				else{
					if($activated==0){
						$usertype="Unpaid User";
						$col1="red";
					}
					else{
						$usertype="Paid User";
						$col1="green";
					}
					
				}
				
				
				?>
				<tr>
						<td><?php echo $ix;?></td> 
						<td><?php echo $u_name;?></td> 
						<td><?php echo $username;?></td> 
						<td style="color:<?php echo $col;?>"><?php echo $position;?></td> 
						<td style="text-align:right;"><?php echo $tbv;?></td> 
						<td style="color:<?php echo $col1;?>"><?php echo $usertype;?></td>
				</tr>
				<?php
				
			}
			?>
			
			
				</tbody> 
			</table>
		 </div>
        </div>
    </div>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="<?php echo base_url();?>js/jquery-3.2.1.min.js"></script>
    <script src="<?php echo base_url();?>js/bootstrap.min.js"></script>
    
  </body>
</html>

<?php 
}
?>